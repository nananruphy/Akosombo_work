package com.example.akosombotour


import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    Toolbar toolbar;
    TabLayout tabLayout;
    ViewPager viewPager;
    PagerAdapter pagerAdapter;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        //link views
        getViews();

        //setting toolbar
        initializeToolBar();

        //adapter setup
        pagerAdapter = new PagerAdapter(getSupportFragmentManager());

        //attaching fragments to adapter
        pagerAdapter.addFragment(new HistoryFragment(),"History");
        pagerAdapter.addFragment(new EthnicgroupsFragment(),"Ethnic Groups");
        pagerAdapter.addFragment(new ToursitesFragment(),"Tour Site");
        pagerAdapter.addFragment(new HotelsFragment(),"Hotels");

        viewPager.setAdapter(pagerAdapter);
        tabLayout.setupWithViewPager(viewPager);

        //setting icons
        tabLayout.getTabAt(0).setIcon(R.drawable.ic_movie_white_24dp);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_movie_white_24dp);
        tabLayout.getTabAt(2).setIcon(R.drawable.ic_movie_white_24dp);
        tabLayout.getTabAt(3).setIcon(R.drawable.ic_movie_white_24dp);
    }


    private void getViews() {
        toolbar = findViewById(R.id.toolBar);
        tabLayout = findViewById(R.id.mTabLayout);
        viewPager = findViewById(R.id.viewPager);
    }

    private void initializeToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Awesome Hollywood Movies");
    }
}